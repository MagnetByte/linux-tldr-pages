# xev

> Print contents of X events.
> More information: <https://manned.org/xev>.

- Monitor all occurring X events:

`xev`

- Monitor all X events of the root window instead of creating a new one:

`xev -root`

- Monitor all X events of a particular window:

`xev -id {{window_id}}`

- Monitor X events from a given category (can be specified multiple times):

`xev -event {{event_category}}`
