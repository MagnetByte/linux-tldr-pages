# gh preview

> Preview GitHub CLI programs for testing and development purposes.
> These commands are unstable and may change at any time.
> More information: <https://cli.github.com/manual/gh_preview>.

- Run a specific preview command:

`gh preview {{command}}`
