# xzcat

> This command is an alias of `xz --decompress --stdout`.

- View documentation for the original command:

`tldr xz`
