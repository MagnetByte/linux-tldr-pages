# elasticsearch-syskeygen

> Create a system key file in the Elasticsearch configuration directory.
> More information: <https://www.elastic.co/docs/reference/elasticsearch/command-line-tools/syskeygen>.

- Generate the `system_key` file in the default `$ES_HOME/config` directory:

`elasticsearch-syskeygen`
