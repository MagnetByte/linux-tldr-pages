# exit

> Exit the shell.
> More information: <https://manned.org/exit.1posix>.

- Exit with the exit status of the most recently executed command:

`exit`

- Exit with a specific exit status:

`exit {{exit_code}}`
