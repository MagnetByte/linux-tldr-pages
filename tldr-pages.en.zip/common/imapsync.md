# imapsync

> Email IMAP tool for syncing, copying, and migrating email mailboxes between two IMAP servers, one way, and without duplicates.
> More information: <https://imapsync.lamiral.info/#doc>.

- Synchronize IMAP account between host1 and host2:

`imapsync --host1 {{host1}} --user1 {{user1}} --password1 {{secret1}} --host2 {{host2}} --user2 {{user2}} --password2 {{secret2}}`
