# go bug

> Report a bug.
> More information: <https://pkg.go.dev/cmd/go#hdr-Start_a_bug_report>.

- Open a web page to start a bug report:

`go bug`
