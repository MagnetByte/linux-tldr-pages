# sc_wartsdump

> Verbose dump of information contained in a `warts` file.
> More information: <https://www.caida.org/catalog/software/scamper/>.

- Output the content of `warts` files verbose:

`sc_wartsdump {{path/to/file1.warts path/to/file2.warts ...}}`
