# file-rename

> This command is an alias of `rename`.

- View documentation for the original command:

`tldr {{[-p|--platform]}} common rename`
