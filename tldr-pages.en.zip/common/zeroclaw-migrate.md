# zeroclaw migrate

> Migrate data from other agent runtimes to ZeroClaw.
> More information: <https://github.com/zeroclaw-labs/zeroclaw#quick-start>.

- Simulate migration from OpenClaw without writing data:

`zeroclaw migrate openclaw --dry-run`

- Migrate memory from OpenClaw workspace:

`zeroclaw migrate openclaw`

- Display help:

`zeroclaw migrate {{[-h|--help]}}`
