# protector

> Protect or unprotect branches on GitHub repositories.
> More information: <https://github.com/jcgay/protector#usage>.

- Protect branches of a GitHub repository (create branch protection rules):

`protector {{branches_regex}} -repos {{organization/repository}}`

- Simulate what would be protected without actually doing it:

`protector -dry-run {{branches_regex}} -repos {{organization/repository}}`

- Free branches of a GitHub repository (delete branch protection rules):

`protector -free {{branches_regex}} -repos {{organization/repository}}`
