# pamtoxvmini

> Convert a Netpbm image to an XV thumbnail picture.
> More information: <https://netpbm.sourceforge.net/doc/pamtoxvmini.html>.

- Convert a PAM image to an XV thumbnail picture:

`pamtoxvmini {{path/to/input_file.pam}} > {{path/to/output_file}}`
