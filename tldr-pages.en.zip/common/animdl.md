# animdl

> Search, stream, and download anime.
> See also: `ani-cli`.
> More information: <https://github.com/justfoolingaround/animdl#usage>.

- Download a specific anime:

`animdl download "{{anime_title}}"`

- Download a specific anime by specifying an episode range:

`animdl download "{{anime_title}}" {{[-r|--range]}} {{start_episode}}-{{end_episode}}`

- Download a specific anime by specifying a download directory:

`animdl download "{{anime_title}}" {{[-d|--download-dir]}} {{path/to/directory}}`

- Grab the stream URL for a specific anime:

`animdl grab "{{anime_title}}"`

- Display the upcoming anime schedule for the next week:

`animdl schedule`

- Search for a specific anime:

`animdl search "{{anime_title}}"`

- Stream a specific anime:

`animdl stream "{{anime_title}}"`

- Stream the latest episode of a specific anime:

`animdl stream "{{anime_title}}" {{[-s|--special]}} latest`
