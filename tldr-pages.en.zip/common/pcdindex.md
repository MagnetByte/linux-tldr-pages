# pcdindex

> This command has been renamed to `pcdovtoppm`.
> More information: <https://netpbm.sourceforge.net/doc/pcdindex.html>.

- View documentation for the command under its current name:

`tldr pcdovtoppm`
