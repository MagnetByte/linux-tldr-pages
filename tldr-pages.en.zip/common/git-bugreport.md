# git bugreport

> Capture debug information from the system and user, generating a text file to aid in the reporting of a bug in Git.
> More information: <https://git-scm.com/docs/git-bugreport>.

- Create a new bug report file in the current directory:

`git bugreport`

- Create a new bug report file in the specified directory, creating it if it does not exist:

`git bugreport {{[-o|--output-directory]}} {{path/to/directory}}`

- Create a new bug report file with the specified filename suffix in `strftime` format:

`git bugreport {{[-s|--suffix]}} {{%m%d%y}}`
