# zeditor

> This command is an alias of `zed`.

- View documentation for the original command:

`tldr zed`
