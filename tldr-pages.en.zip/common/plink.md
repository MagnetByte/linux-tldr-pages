# plink

> PuTTy's command line utility.
> See also: `ssh`.
> More information: <https://manned.org/plink>.

- Connect to an address:

`plink {{IP_address}}`
