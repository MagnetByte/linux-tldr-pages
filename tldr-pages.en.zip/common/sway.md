# sway

> A tiling Wayland compositor.
> It uses the same config format as `i3`, with some Wayland-specific additions.
> More information: <https://github.com/swaywm/sway/wiki>.

- Start `sway`:

`sway`

- View documentation for `i3` (`sway` uses the same default keybindings):

`tldr i3`
