# rnano

> This command is an alias of `nano --restricted`.
> More information: <https://manned.org/rnano>.

- View documentation for the original command:

`tldr nano`
