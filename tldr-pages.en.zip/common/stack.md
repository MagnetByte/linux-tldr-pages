# stack

> Manage Haskell projects.
> More information: <https://docs.haskellstack.org/en/stable/commands/>.

- Create a new package:

`stack new {{package}} {{template}}`

- Compile a package:

`stack build`

- Run tests inside a package:

`stack test`

- Compile a project and re-compile every time a file changes:

`stack build --file-watch`

- Compile a project and execute a command after compilation:

`stack build --exec "{{command}}"`

- Run a program and pass an argument to it:

`stack exec {{program}} -- {{argument}}`
