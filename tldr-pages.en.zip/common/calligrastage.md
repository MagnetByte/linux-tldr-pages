# calligrastage

> Calligra's presentation application.
> See also: `calligraflow`, `calligrawords`, `calligrasheets`.
> More information: <https://manned.org/calligrastage>.

- Launch the presentation application:

`calligrastage`

- Open a specific presentation:

`calligrastage {{path/to/presentation}}`

- Display help or version:

`calligrastage --{{help|version}}`
