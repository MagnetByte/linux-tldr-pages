# fast

> Test your download and upload speed using fast.com.
> More information: <https://github.com/sindresorhus/fast-cli>.

- Measure the current download speed:

`fast`

- Measure the current upload speed in addition to download speed:

`fast {{[-u|--upload]}}`

- Display results on a single line to reduce spacing:

`fast --single-line`

- Display complete results - download/upload speeds, latency, and ISP info:

`fast --verbose`
