# sbcl

> High performance Common Lisp compiler.
> More information: <https://www.sbcl.org/manual/index.html#Command-Line-Options>.

- Start a REPL (interactive shell):

`sbcl`

- Execute a Lisp script:

`sbcl --script {{path/to/script.lisp}}`
