# declare

> Declare variables and give them attributes.
> See also: `alias`.
> More information: <https://www.gnu.org/software/bash/manual/bash.html#index-declare>.

- Declare a string variable with the specified value:

`declare {{variable}}="{{value}}"`

- Declare an integer variable with the specified value:

`declare -i {{variable}}="{{value}}"`

- Declare an array variable with the specified value:

`declare -a {{variable}}=({{item_a item_b item_c}})`

- Declare an associative array variable with the specified value:

`declare -A {{variable}}=({{[key_a]=item_a [key_b]=item_b [key_c]=item_c}})`

- Declare a readonly string variable with the specified value:

`declare -r {{variable}}="{{value}}"`

- Declare a global variable within a function with the specified value:

`declare -g {{variable}}="{{value}}"`

- Print a function definition:

`declare -f {{function_name}}`

- Print a variable definition:

`declare -p {{variable_name}}`
