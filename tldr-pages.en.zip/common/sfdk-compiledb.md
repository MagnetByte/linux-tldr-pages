# sfdk compiledb

> Generate compilation database.
> More information: <https://github.com/sailfishos/sailfish-qtcreator/blob/master/share/qtcreator/sfdk/modules/70-ide-compiledb/doc/command.compiledb.adoc>.

- Generate compilation database:

`sfdk compiledb`

- Generate compilation database with extra `make` arguments:

`sfdk compiledb {{arguments}}`
