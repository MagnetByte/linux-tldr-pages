# ppmrelief

> Produce a relief of a PPM image.
> More information: <https://netpbm.sourceforge.net/doc/ppmrelief.html>.

- Produce a relief of the specified PPM image:

`ppmrelief {{path/to/input_file.ppm}} > {{path/to/output_file.ppm}}`
