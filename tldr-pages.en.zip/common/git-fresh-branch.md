# git fresh-branch

> Create an empty local branch.
> Part of `git-extras`.
> More information: <https://github.com/tj/git-extras/blob/main/Commands.md#git-fresh-branch>.

- Create an empty local branch:

`git fresh-branch {{branch_name}}`
