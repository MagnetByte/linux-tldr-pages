# zbarimg

> Scan and decode bar codes from image file(s).
> More information: <https://manned.org/zbarimg>.

- Process an image file:

`zbarimg {{image_file}}`
