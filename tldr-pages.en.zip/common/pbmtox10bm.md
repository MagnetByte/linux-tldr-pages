# pbmtox10bm

> This command has been superseded by `pbmtoxbm -x10`.
> More information: <https://netpbm.sourceforge.net/doc/pbmtox10bm.html>.

- View documentation for the current command:

`tldr pbmtoxbm`
