# gpg-tui

> Terminal user interface for GNU Privacy Guard.
> More information: <https://github.com/orhun/gpg-tui>.

- Start `gpg-tui`:

`gpg-tui`

- Start `gpg-tui` with color and ASCII armored output:

`gpg-tui {{[-s|--style]}} {{colored}} {{[-a|--armor]}}`

- Quit `gpg-tui`:

`<q>`

- Interactively generate a new key:

`<g>`

- Export the selected key:

`<x>`

- Set the detail level for the selected key:

`<1>|<2>|<3>`

- Refresh `gpg-tui`:

`<r>`

- Display help in `gpg-tui`:

`<?>`
