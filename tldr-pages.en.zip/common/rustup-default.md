# rustup default

> Set the default Rust toolchain.
> More information: <https://rust-lang.github.io/rustup>.

- Switch the default Rust toolchain (see `rustup help toolchain` for more information):

`rustup default {{toolchain}}`
