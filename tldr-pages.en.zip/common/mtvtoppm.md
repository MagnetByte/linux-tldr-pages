# mtvtoppm

> Convert an MTV or PRT ray tracer file to a PPM image.
> More information: <https://netpbm.sourceforge.net/doc/mtvtoppm.html>.

- Convert an MTV or PRT ray tracer file to a PPM image:

`mtvtoppm {{path/to/file.mtv}} > {{path/to/output.ppm}}`
