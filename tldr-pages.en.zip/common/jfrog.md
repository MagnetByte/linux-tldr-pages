# jfrog

> This command is an alias of `jf`.

- View documentation for the original command:

`tldr jf`
