# npm prune

> Remove extraneous packages from `node_modules`.
> Note: Extraneous packages are those present in the node_modules folder that are not listed as any package's dependency list.
> More information: <https://docs.npmjs.com/cli/npm-prune/>.

- Remove all extraneous packages not listed in dependencies:

`npm prune`

- Remove extraneous packages and devDependencies (useful for production builds):

`npm prune --production`

- Simulate pruning, showing what would be removed without making any changes:

`npm prune --dry-run`

- Output the changes as JSON:

`npm prune --json`

- Remove specific packages by name:

`npm prune {{package_name}}`
