# w3m

> A text-based web browser.
> Supports SSL and mouse input, even over SSH.
> More information: <https://w3m.sourceforge.net/MANUAL>.

- Open a URL:

`w3m {{https://example.com}}`

- Open a URL in monochrome mode:

`w3m {{https://example.com}} -M`

- Open a URL without mouse support:

`w3m {{https://example.com}} -no-mouse`

- Open a new browser tab:

`<Shift t>`

- Display your browser history:

`<Ctrl h>`

- Quit w3m:

`<q><y>`
