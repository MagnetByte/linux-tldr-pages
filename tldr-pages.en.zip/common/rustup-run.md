# rustup run

> Run a command with an environment configured for a Rust toolchain.
> Note: All commands managed by `rustup` have a shorthand for this: for example, `cargo +nightly build` is equivalent to `rustup run nightly cargo build`.
> More information: <https://rust-lang.github.io/rustup/>.

- Run a command using a given Rust toolchain (see `rustup help toolchain` for more information):

`rustup run {{toolchain}} {{command}}`
