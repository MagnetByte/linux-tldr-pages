# pulumi down

> This command is an alias of `pulumi destroy`.

- View documentation for the original command:

`tldr pulumi destroy`
