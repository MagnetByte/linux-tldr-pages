# impacket-mqtt_check

> This command is an alias of `mqtt_check.py`.

- View documentation for the original command:

`tldr mqtt_check.py`
