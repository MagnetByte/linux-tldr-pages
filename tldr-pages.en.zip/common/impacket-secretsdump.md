# impacket-secretsdump

> This command is an alias of `secretsdump.py`.

- View documentation for the original command:

`tldr secretsdump.py`
