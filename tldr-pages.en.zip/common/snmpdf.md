# snmpdf

> Fetch disk space usage information.
> More information: <https://manned.org/snmpdf>.

- Fetch the disk space usage:

`snmpdf -v {{version}} -c {{community}} {{ip_address}}`

- Display help:

`snmpdf {{[-h|--help]}}`
