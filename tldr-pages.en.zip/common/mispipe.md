# mispipe

> Pipe two commands and return the exit status of the first command.
> More information: <https://manned.org/mispipe>.

- Pipe two commands and return the exit status of the first command:

`mispipe {{command1}} {{command2}}`
