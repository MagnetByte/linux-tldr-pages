# virsh pool-destroy

> Stop an active virtual machine storage pool.
> See also: `virsh`, `virsh-pool-delete`.
> More information: <https://manned.org/virsh>.

- Stop a storage pool specified by name or UUID (determine using `virsh pool-list`):

`virsh pool-destroy --pool {{name|uuid}}`
