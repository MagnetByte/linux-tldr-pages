# pbmtoatk

> Convert a PBM image to an Andrew Toolkit raster object.
> See also: `atktopbm`.
> More information: <https://netpbm.sourceforge.net/doc/pbmtoatk.html>.

- Convert a PBM image to an Andrew Toolkit raster object:

`pbmtoatk {{path/to/image.pbm}} > {{path/to/output.atk}}`
