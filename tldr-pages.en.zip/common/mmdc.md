# mmdc

> CLI for mermaid, a diagram generation tool with a domain-specific language.
> A mermaid definition file is taken as input and a SVG, PNG, or PDF file is generated as output.
> More information: <http://mermaid.js.org/>.

- Convert a file to the specified format (automatically determined from the file extension):

`mmdc {{[-i|--input]}} {{input.mmd}} {{[-o|--output]}} {{output.svg}}`

- Specify the theme of the chart:

`mmdc {{[-i|--input]}} {{input.mmd}} {{[-o|--output]}} {{output.svg}} {{[-t|--theme]}} {{forest|dark|neutral|default}}`

- Specify the background color of the chart (e.g. `lime`, `"#D8064F"`, or `transparent`):

`mmdc {{[-i|--input]}} {{input.mmd}} {{[-o|--output]}} {{output.svg}} {{[-b|--backgroundColor]}} {{color}}`
