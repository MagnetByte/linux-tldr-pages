# pulumi version

> Display Pulumi's version number.
> More information: <https://www.pulumi.com/docs/iac/cli/commands/pulumi_version/>.

- Display version:

`pulumi version`

- Display help:

`pulumi version {{[-h|--help]}}`
