# pulumi gen-completion

> Generate completion scripts for the Pulumi CLI.
> Supported shells are bash, zsh, fish.
> More information: <https://www.pulumi.com/docs/iac/cli/commands/pulumi_gen-completion/>.

- Generate completion scripts:

`pulumi gen-completion {{bash|zsh|fish}}`
