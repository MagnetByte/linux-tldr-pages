# lispmtopgm

> Convert a Lisp Machine bitmap into a PGM image.
> See also: `pgmtolispm`.
> More information: <https://netpbm.sourceforge.net/doc/lispmtopgm.html>.

- Convert the specified Lisp Machine bitmap file into a PGM image:

`lispmtopgm {{path/to/input.lispm}} > {{path/to/output.pgm}}`
