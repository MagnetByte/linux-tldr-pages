# git continue

> This command is an alias of `git abort`.

- View documentation for the original command:

`tldr git abort`
