# gnucash

> Personal and small-business financial-accounting software.
> More information: <https://manned.org/gnucash>.

- Launch GnuCash and load the previously opened file:

`gnucash`

- Launch GnuCash and load the specified file:

`gnucash {{path/to/file.gnucash}}`

- Launch GnuCash and load an empty file:

`gnucash --nofile`
