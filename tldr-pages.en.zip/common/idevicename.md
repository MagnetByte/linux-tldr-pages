# idevicename

> Display the device name or set it to a new name.
> More information: <https://manned.org/idevicename>.

- Display the current device name:

`idevicename`

- Set a new device name:

`idevicename {{new_name}}`
