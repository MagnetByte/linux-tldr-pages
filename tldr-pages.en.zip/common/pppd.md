# pppd

> Establish Point-to-Point connection to another computer.
> It should not be invoked manually.
> More information: <https://ppp.samba.org/pppd.html>.

- Start the daemon:

`pppd`
