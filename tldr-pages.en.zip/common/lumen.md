# lumen

> An installer for the Lumen micro-framework.
> More information: <https://lumen.laravel.com>.

- Create a new Lumen application:

`lumen new {{application_name}}`

- List the available installer commands:

`lumen list`
