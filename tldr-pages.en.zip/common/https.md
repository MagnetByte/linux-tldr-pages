# https

> This command is an alias of `http`.

- View documentation for the original command:

`tldr http`
