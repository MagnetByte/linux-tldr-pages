# pbmtoplot

> Convert a PBM image into a UNIX plot file.
> More information: <https://netpbm.sourceforge.net/doc/pbmtoplot.html>.

- Convert a PBM image into a UNIX plot file:

`pbmtoplot {{path/to/image.pbm}} > {{path/to/output.plot}}`
