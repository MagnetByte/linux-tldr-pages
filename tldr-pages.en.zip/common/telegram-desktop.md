# telegram-desktop

> Instant messenger with open source clients, chats and stickers.
> More information: <https://telegram.org>.

- Start GUI:

`telegram-desktop`

- Run GUI as an autostart if allowed:

`telegram-desktop -autostart`

- Run GUI minimized to tray:

`telegram-desktop -startintray`
