# pgmcrater

> This command has been superseded by `pamcrater`, `pamshadedrelief`, and `pamtopnm`.
> More information: <https://netpbm.sourceforge.net/doc/pgmcrater.html>.

- View documentation for `pamcrater`:

`tldr pamcrater`

- View documentation for `pamshadedrelief`:

`tldr pamshadedrelief`

- View documentation for `pamtopnm`:

`tldr pamtopnm`
