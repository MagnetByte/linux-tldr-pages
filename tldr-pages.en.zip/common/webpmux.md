# webpmux

> Create WebP animations.
> More information: <https://developers.google.com/speed/webp/docs/webpmux>.

- Create a two-frame animation:

`webpmux -frame {{path/to/frame1.webp}} +{{500}} -frame {{path/to/frame2.webp}} +{{500}} -loop {{0}} -o {{path/to/output.webp}}`
