# kubectl taint

> Update the taints on nodes.
> More information: <https://kubernetes.io/docs/reference/kubectl/generated/kubectl_taint/>.

- Apply taint to a node:

`kubectl taint {{[no|nodes]}} {{node_name}} {{label_key}}={{label_value}}:{{effect}}`

- Remove taint from a node:

`kubectl taint {{[no|nodes]}} {{node_name}} {{label_key}}:{{effect}}-`

- Remove all taints from a node:

`kubectl taint {{[no|nodes]}} {{node_name}} {{label_key}}-`
