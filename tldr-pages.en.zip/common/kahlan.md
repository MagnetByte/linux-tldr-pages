# kahlan

> A unit and behavior-driven development test framework for PHP.
> More information: <https://kahlan.github.io/docs/cli-options.html>.

- Run all specifications in the "spec" directory:

`kahlan`

- Run specifications using a specific configuration file:

`kahlan --config={{path/to/configuration_file}}`

- Run specifications and output using a reporter:

`kahlan --reporter={{dot|bar|json|tap|verbose}}`

- Run specifications with code coverage (detail can be between 0 and 4):

`kahlan --coverage={{0..4}}`
