# sngrep

> Display SIP calls message flows from terminal.
> More information: <https://manned.org/sngrep>.

- Visualize SIP packets from a PCAP file:

`sngrep -I {{path/to/file.pcap}}`

- Visualize only dialogs starting with INVITE packets with RTP packets from a PCAP file:

`sngrep -crI {{path/to/file.pcap}}`

- Display a real-time interface with only dialogs starting with INVITE packets, including RTP packets:

`sngrep -cr`

- Only capture packets without interface to a file:

`sngrep -NO {{path/to/file.pcap}}`
