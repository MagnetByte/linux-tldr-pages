# minio-client

> This command is an alias of `mc` (MinIO client).

- View documentation for the original command:

`tldr mc.cli`
