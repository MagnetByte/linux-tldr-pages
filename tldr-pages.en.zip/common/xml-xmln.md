# xml xmln

> This command is an alias of `xml pyx`.

- View documentation for the original command:

`tldr xml pyx`
