# sfdk apply

> Apply patches from RPM SPEC file.
> More information: <https://github.com/sailfishos/sailfish-qtcreator/blob/master/share/qtcreator/sfdk/modules/20-building-mb2/doc/command.apply.adoc>.

- Apply all patches:

`sfdk apply`

- Reverse apply all patches:

`sfdk apply -R`
