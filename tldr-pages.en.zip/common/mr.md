# mr

> Manage all of your version control repositories at once.
> More information: <https://manned.org/mr>.

- Register a repository:

`mr register`

- Update repositories in 5 concurrent jobs:

`mr {{[-j|--jobs]}} {{5}} update`

- Print the status of all repositories:

`mr status`

- Checkout all repositories to the latest version:

`mr checkout`
