# nix-store

> `nix-store` can refer to multiple commands with the same name.

- View documentation for the traditional store:

`tldr nix-store.2`

- View documentation for nix3 store:

`tldr nix store.3`
