# tlmgr recreate-tlpdb

> Recreate the TeX Live package database.
> This command has a lack of documentation and should be used with caution.
> More information: <https://www.tug.org/texlive/tlmgr.html>.

- Recreate the `texlive.tlpdb` database file and dump it to `stdout`:

`sudo tlmgr recreate-tlpdb`
