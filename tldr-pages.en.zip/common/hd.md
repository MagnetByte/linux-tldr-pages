# hd

> This command is an alias of `hexdump`.

- View documentation for the original command:

`tldr hexdump`
