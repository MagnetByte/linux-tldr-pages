# npm run-script

> This command is an alias of `npm run`.

- View documentation for the original command:

`tldr npm run`
