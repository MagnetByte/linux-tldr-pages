# lckdo

> This command is deprecated and has been superseded by `flock`.
> More information: <https://manned.org/lckdo>.

- View documentation for the recommended replacement:

`tldr flock`
