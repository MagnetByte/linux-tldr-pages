# unxz

> This command is an alias of `xz --decompress`.

- View documentation for the original command:

`tldr xz`
