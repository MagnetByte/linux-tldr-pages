# impacket-psexec

> This command is an alias of `psexec.py`.

- View documentation for the original command:

`tldr psexec.py`
