# jo

> This command is an alias of `autojump`.

- View documentation for the original command:

`tldr autojump`
