# npm shrinkwrap

> Lock down the dependencies of a package, creating an `npm-shrinkwrap.json` file.
> Similar to `package-lock.json` but intended for published packages.
> More information: <https://docs.npmjs.com/cli/v11/npm-shrinkwrap>.

- Generate an `npm-shrinkwrap.json` file from the current `package-lock.json`:

`npm shrinkwrap`

- Run in production mode (excludes devDependencies):

`npm shrinkwrap --production`

- Force recreate the shrinkwrap file even if it already exists:

`npm shrinkwrap --force`
