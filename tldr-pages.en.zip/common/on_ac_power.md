# on_ac_power

> A simple utility which tests if a computer is running on line power.
> Returns `0` if yes, and `1` if no.
> More information: <https://manned.org/on_ac_power>.

- Test if a computer is running on line power:

`on_ac_power`
