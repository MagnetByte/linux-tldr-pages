# mix

> Build tool that provides tasks for creating, compiling, and testing Elixir projects, managing its dependencies, and more.
> More information: <https://hexdocs.pm/mix/index.html>.

- Execute a particular file:

`mix run {{my_script.exs}}`

- Create a new project:

`mix new {{project_name}}`

- Compile project:

`mix compile`

- Run project tests:

`mix test`

- Display help:

`mix help`
