# jc

> `jc` can refer to multiple commands with the same name.

- View documentation for the `JSON` serializer:

`tldr jc.json`

- View documentation for the `autojump` alias:

`tldr autojump`
