# ppmtojpeg

> This command has been superseded by `pnmtojpeg`.
> More information: <https://netpbm.sourceforge.net/doc/ppmtojpeg.html>.

- View documentation for the current command:

`tldr pnmtojpeg`
