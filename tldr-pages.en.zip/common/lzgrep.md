# lzgrep

> This command is an alias of `xzgrep`.

- View documentation for the original command:

`tldr xzgrep`
