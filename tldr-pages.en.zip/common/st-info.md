# st-info

> Get information about connected STLink and STM32 devices.
> More information: <https://github.com/stlink-org/stlink/blob/testing/doc/man/st-info.md>.

- Display amount of program memory available:

`st-info --flash`

- Display amount of SRAM memory available:

`st-info --sram`

- Display summarized information of the device:

`st-info --probe`
