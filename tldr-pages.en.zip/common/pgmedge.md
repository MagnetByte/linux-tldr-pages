# pgmedge

> This command has been superseded by `pamedge`.
> More information: <https://netpbm.sourceforge.net/doc/pgmedge.html>.

- View documentation for the current command:

`tldr pamedge`
