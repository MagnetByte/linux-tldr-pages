# docker top

> This command is an alias of `docker container top`.

- View documentation for the original command:

`tldr docker container top`
