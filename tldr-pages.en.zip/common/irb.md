# irb

> Interactive Ruby shell.
> Evaluate Ruby code read from `stdin`.
> More information: <https://ruby.github.io/irb/>.

- Start the interactive shell:

`irb`
