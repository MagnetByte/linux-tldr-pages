# gnmic sub

> This command is an alias of `gnmic subscribe`.

- View documentation for the original command:

`tldr gnmic subscribe`
