# sc_wartsfix

> Truncate damaged `warts` files.
> More information: <https://www.caida.org/catalog/software/scamper/>.

- Save all records (in a separate file) up to the last intact one:

`sc_wartsfix {{path/to/file1.warts path/to/file2.warts ...}}`
