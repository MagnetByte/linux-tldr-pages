# pgmnorm

> This command has been superseded by `pnmnorm`.
> More information: <https://netpbm.sourceforge.net/doc/pgmnorm.html>.

- View documentation for the current command:

`tldr pnmnorm`
