# mpiexec

> This command is an alias of `mpirun`.

- View documentation for the original command:

`tldr mpirun`
