# prename

> This command is an alias of `rename`.

- View documentation for the original command:

`tldr -p common rename`
