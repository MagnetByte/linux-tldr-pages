# pgmtosbig

> Convert a PGM image to the SBIG CCDOPS format.
> More information: <https://netpbm.sourceforge.net/doc/pgmtosbig.html>.

- Convert a PGM image file to the SBIG CCDOPS format:

`pgmtosbig {{path/to/input_file.pgm}} > {{path/to/output.sbig}}`
