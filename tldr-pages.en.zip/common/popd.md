# popd

> Remove a directory placed on the directory stack via the `pushd` shell built-in.
> See also: `pushd`, `dirs`.
> More information: <https://www.gnu.org/software/bash/manual/bash.html#index-popd>.

- Remove the top directory from the stack and cd to it:

`popd`

- Remove the Nth directory (starting from zero to the left from the list printed with `dirs`):

`popd +N`

- Remove the Nth directory (starting from zero to the right from the list printed with `dirs`):

`popd -N`

- Remove the 1st directory (starting from zero to the left from the list printed with `dirs`):

`popd -n`
