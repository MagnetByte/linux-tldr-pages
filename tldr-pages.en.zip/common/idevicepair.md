# idevicepair

> Manage host pairings with iOS devices.
> More information: <https://manned.org/idevicepair>.

- Pair a device with the host:

`idevicepair pair`

- List devices paired with the host:

`idevicepair list`
