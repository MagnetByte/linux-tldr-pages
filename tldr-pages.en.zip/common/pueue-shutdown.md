# pueue shutdown

> Remotely shut down the daemon.
> Only use this subcommand if the daemon isn't started by a service manager.
> More information: <https://github.com/Nukesor/pueue>.

- Shutdown the daemon without a service manager:

`pueue shutdown`
