# freeramdisk

> Free memory used by `loadlin` ramdisk on legacy systems.
> Largely deprecated by `umount`, `losetup`, and `tmpfs`.
> More information: <https://manned.org/freeramdisk>.

- Free `loadlin` ramdisk memory:

`sudo freeramdisk`
