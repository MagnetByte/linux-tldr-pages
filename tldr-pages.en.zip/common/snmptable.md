# snmptable

> Fetch data in tabular format.
> More information: <https://manned.org/snmptable>.

- Fetch data:

`snmptable -v {{version}} -c {{community}} {{ip}} {{oid}}`

- Display help:

`snmptable {{[-h|--help]}}`
