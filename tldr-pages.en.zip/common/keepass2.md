# keepass2

> A light-weight password manager.
> More information: <https://manned.org/keepass2>.

- Start KeePass 2, opening the most recently opened password database:

`keepass2`

- Start KeePass 2, opening a specific password database:

`keepass2 {{path/to/database.kbdx}}`

- Use a specific key file to open a password database:

`keepass2 {{path/to/database.kbdx}} -keyfile:{{path/to/key_file.key}}`
