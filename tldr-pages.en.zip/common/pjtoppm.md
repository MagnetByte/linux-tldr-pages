# pjtoppm

> Convert a HP PaintJet file to PPM.
> More information: <https://netpbm.sourceforge.net/doc/pjtoppm.html>.

- Convert a HP PaintJet file to PPM:

`pjtoppm {{path/to/input.pj}} > {{path/to/output.ppm}}`
