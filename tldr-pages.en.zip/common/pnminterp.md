# pnminterp

> This command has been superseded by `pamstretch`.
> More information: <https://netpbm.sourceforge.net/doc/pnminterp.html>.

- View documentation for the current command:

`tldr pamstretch`
