# now

> Cloud platform for serverless deployment.
> Note: This command is deprecated, use `vercel` instead.
> More information: <https://vercel.com/home>.

- Deploy the current directory:

`now`

- Display a list of deployments:

`now list`

- Display information related to a deployment:

`now inspect {{deployment_url}}`

- Remove a deployment:

`now remove {{deployment_id}}`

- Log in into an account or create a new one:

`now login`

- Initialize an example project (a new directory will be created):

`now init`
