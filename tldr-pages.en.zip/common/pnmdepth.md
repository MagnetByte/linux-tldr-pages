# pnmdepth

> This command is an alias of `pamdepth`.

- View documentation for the original command:

`tldr pamdepth`
