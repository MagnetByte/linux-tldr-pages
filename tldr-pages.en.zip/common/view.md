# view

> A read-only version of `vim`.
> This is equivalent to `vim -R`.
> More information: <https://www.vim.org>.

- Open a file:

`view {{path/to/file}}`
