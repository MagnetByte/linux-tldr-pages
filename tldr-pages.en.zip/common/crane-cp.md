# crane cp

> This command is an alias of `crane copy`.

- View documentation for the original command:

`tldr crane copy`
