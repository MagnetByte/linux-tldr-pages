# unp

> Extract any archive.
> Relevant extractors need to be installed, e.g. `unrar` for RAR.
> More information: <https://manned.org/unp>.

- Extract an archive:

`unp {{path/to/archive.zip}}`

- Extract multiple archives:

`unp {{path/to/archive1.tar.gz}} {{path/to/archive2.rar}}`
