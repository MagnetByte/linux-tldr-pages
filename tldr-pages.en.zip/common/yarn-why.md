# yarn-why

> Identifies why a Yarn package has been installed.
> More information: <https://github.com/amio/yarn-why>.

- Show why a Yarn package is installed:

`yarn-why {{package}}`
