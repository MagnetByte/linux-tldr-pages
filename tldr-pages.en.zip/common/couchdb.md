# couchdb

> Command-line interface for Apache CouchDB database server.
> More information: <https://manned.org/couchdb>.

- Start CouchDB:

`couchdb`

- Start CouchDB interactive shell:

`couchdb -i`

- Start CouchDB as a background process:

`couchdb -b`

- Kill the background process (Note: It will respawn if needed):

`couchdb -k`

- Shut down the background process:

`couchdb -d`
