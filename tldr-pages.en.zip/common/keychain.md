# keychain

> Re-use ssh-agent and/or gpg-agent between logins.
> More information: <https://www.funtoo.org/Keychain>.

- Check for a running ssh-agent, and start one if needed:

`keychain`

- Also check for gpg-agent:

`keychain --agents "{{gpg,ssh}}"`

- List signatures of all active keys:

`keychain --list`

- List fingerprints of all active keys:

`keychain --list-fp`

- Add a timeout for identities added to the agent, in minutes:

`keychain --timeout {{minutes}}`
