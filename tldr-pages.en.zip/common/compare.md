# compare

> This command is an alias of `magick compare`.

- View documentation for the original command:

`tldr magick compare`
