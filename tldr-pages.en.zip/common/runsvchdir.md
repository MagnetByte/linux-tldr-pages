# runsvchdir

> Change the directory `runsvdir` uses by default.
> More information: <https://manned.org/runsvchdir.8>.

- Switch `runsvdir` directories:

`sudo runsvchdir {{path/to/directory}}`
