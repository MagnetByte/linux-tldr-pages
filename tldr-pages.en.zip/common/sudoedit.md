# sudoedit

> This command is an alias of `sudo --edit`.

- View documentation for the original command:

`tldr sudo`
