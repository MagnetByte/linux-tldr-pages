# pulumi update

> This command is an alias of `pulumi up`.

- View documentation for the original command:

`tldr pulumi up`
