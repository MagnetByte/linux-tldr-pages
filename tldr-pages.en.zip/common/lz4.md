# lz4

> Compress or decompress .lz4 files.
> More information: <https://github.com/lz4/lz4>.

- Compress a file:

`lz4 {{path/to/file}}`

- Decompress a file:

`lz4 {{[-d|--decompress]}} {{file.lz4}}`

- Decompress a file and write to `stdout`:

`lz4 {{[-dc|--decompress --stdout]}} {{file.lz4}}`

- Package and compress a directory and its contents:

`tar cvf - {{path/to/directory}} | lz4 - {{dir.tar.lz4}}`

- Decompress and unpack a directory and its contents:

`lz4 {{[-dc|--decompress --stdout]}} {{dir.tar.lz4}} | tar -xv`

- Compress a file using the best compression:

`lz4 {{[-12|--best]}} {{path/to/file}}`
