# pueue switch

> Switches the queue position of two enqueued or stashed commands.
> More information: <https://github.com/Nukesor/pueue>.

- Switch the priority of two tasks:

`pueue switch {{task_id1}} {{task_id2}}`
