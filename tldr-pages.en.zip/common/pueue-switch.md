# pueue switch

> Switch the queue position of two enqueued or stashed commands.
> More information: <https://github.com/Nukesor/pueue#how-to-use-it>.

- Switch the priority of two tasks:

`pueue switch {{task_id1}} {{task_id2}}`
