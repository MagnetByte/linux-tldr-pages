# tlmgr candidates

> Get available candidate repositories from which a TeX Live package can be installed.
> More information: <https://www.tug.org/texlive/doc/tlmgr.html#candidates-pkg>.

- List all available repositories from which a package can be installed:

`tlmgr candidates {{package}}`
