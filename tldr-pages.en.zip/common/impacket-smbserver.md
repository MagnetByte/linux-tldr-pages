# impacket-smbserver

> This command is an alias of `smbserver.py`.

- View documentation for the original command:

`tldr smbserver.py`
