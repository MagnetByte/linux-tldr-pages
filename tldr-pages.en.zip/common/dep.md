# dep

> Deploy PHP applications.
> Note: The Go command `dep` with the same name is deprecated and archived.
> More information: <https://deployer.org/docs/8.x/cli>.

- Interactively initialize deployer in the local path (use a framework template with `--template=template`):

`dep init`

- Deploy an application to a remote host:

`dep deploy {{hostname}}`

- Roll back to the previous working release:

`dep rollback`

- Connect to a remote host via SSH:

`dep ssh {{hostname}}`

- List commands:

`dep list`

- Run any arbitrary command on the remote hosts:

`dep run "{{command}}"`

- Display help for a command:

`dep help {{command}}`
