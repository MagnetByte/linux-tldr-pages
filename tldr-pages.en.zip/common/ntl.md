# ntl

> This command is an alias of `netlify`.

- View documentation for the original command:

`tldr netlify`
