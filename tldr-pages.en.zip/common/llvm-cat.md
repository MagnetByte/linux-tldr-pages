# llvm-cat

> Concatenate LLVM Bitcode (`.bc`) files.
> More information: <https://github.com/llvm/llvm-project/blob/main/llvm/tools/llvm-cat/llvm-cat.cpp>.

- Concatenate Bitcode files:

`llvm-cat {{path/to/file1.bc}} {{path/to/file2.bc}} -o {{path/to/out.bc}}`
