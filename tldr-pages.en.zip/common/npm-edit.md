# npm edit

> Select a dependency in the current project and open the package folder in the default editor (`$EDITOR`).
> After editing, the package is rebuilt to pick up any changes in compiled packages.
> More information: <https://docs.npmjs.com/cli/npm-edit/>.

- Edit a locally installed package in the default editor:

`npm edit {{package_name}}`
