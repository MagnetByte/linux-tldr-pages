# ppmtouil

> This command has been superseded by `pamtouil`.
> More information: <https://netpbm.sourceforge.net/doc/ppmtouil.html>.

- View documentation for the current command:

`tldr pamtouil`
