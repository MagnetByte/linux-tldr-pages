# grip

> Preview GitHub-flavored Markdown files locally.
> More information: <https://manned.org/grip>.

- Start the server and serve the rendered `README` file of a current directory:

`grip`

- Start the server and serve a specific Markdown file:

`grip {{path/to/file.md}}`

- Start the server and open the `README` file of the current directory in the browser:

`grip {{[-b|--browser]}}`

- Start the server in the specified port and serve the rendered `README` file of the current directory:

`grip {{port}}`
