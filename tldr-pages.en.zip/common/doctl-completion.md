# doctl completion

> Generate the autocompletion script for `doctl` for the specified shell.
> Note: This subcommand does not have a documentation page and is likely deprecated.
> More information: <https://docs.digitalocean.com/reference/doctl/reference/>.

- Generate the autocompletion script for Bash:

`doctl completion bash`

- Generate the autocompletion script for fish:

`doctl completion fish`

- Generate the autocompletion script for PowerShell:

`doctl completion powershell`

- Generate the autocompletion script for Zsh:

`doctl completion zsh`
