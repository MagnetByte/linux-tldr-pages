# impacket-rpcmap

> This command is an alias of `rpcmap.py`.

- View documentation for the original command:

`tldr rpcmap.py`
