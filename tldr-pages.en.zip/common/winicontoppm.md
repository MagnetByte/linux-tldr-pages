# winicontoppm

> This command has been superseded by `winicontopam`.
> More information: <https://netpbm.sourceforge.net/doc/winicontoppm.html>.

- View documentation for the current command:

`tldr winicontopam`
