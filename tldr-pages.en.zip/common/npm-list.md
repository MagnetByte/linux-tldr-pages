# npm list

> This command is an alias of `npm ls`.

- View documentation for the original command:

`tldr npm ls`
