# nyxt

> A keyboard-driven web browser for power users.
> More information: <https://nyxt-browser.com/documentation>.

- List all profiles:

`nyxt --list-data-profiles`

- Set the `init.lisp` file path:

`nyxt --init {{path/to/file}}`

- Change the path to the auto-config file:

`nyxt --auto-config {{path/to/file}}`

- Print system information:

`nyxt --system-information`
