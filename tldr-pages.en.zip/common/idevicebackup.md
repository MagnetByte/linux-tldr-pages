# idevicebackup

> Create or restore backups for iOS devices.
> Note: This tool is outdated. Please see `idevicebackup2`.
> More information: <https://manned.org/idevicebackup>.

- Create a backup of the device in the specified directory:

`idevicebackup backup {{path/to/directory}}`

- Restore a backup from the specified directory:

`idevicebackup restore {{path/to/directory}}`
