# expo

> Build, develop, and deploy React Native apps.
> More information: <https://docs.expo.dev/eas/>.

- Build an Android APK or AAB:

`expo build:android`

- Build an iOS IPA:

`expo build:ios`

- Run the app in Expo Go:

`expo start`

- Install a dependency:

`expo install {{package_name}}`

- Prebuild native Android/iOS projects:

`expo prebuild`

- Run the app on Android:

`expo run:android`

- Run the app on iOS:

`expo run:ios`
