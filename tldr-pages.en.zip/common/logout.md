# logout

> Exit a login shell.
> More information: <https://www.gnu.org/software/bash/manual/bash.html#index-logout>.

- Exit a login shell:

`logout`

- Exit a login shell and specify a return value:

`logout {{exit_code}}`
