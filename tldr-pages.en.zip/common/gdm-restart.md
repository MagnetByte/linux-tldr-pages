# gdm-restart

> Restart the GNOME Display Manager (GDM) daemon.
> See also: `gdm`, `gdm-binary`, `gdmsetup`, `gdm-stop`, `gdm-safe-restart`.
> More information: <https://manned.org/gdm>.

- Restart the GNOME Display Manager application:

`gdm-restart`
