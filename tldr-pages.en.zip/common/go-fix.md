# go fix

> Update packages to use new APIs.
> More information: <https://pkg.go.dev/cmd/go#hdr-Update_packages_to_use_new_APIs>.

- Update packages to use new APIs:

`go fix {{packages}}`
