# showfigfonts

> Display available figlet fonts.
> See also: `figlet`.
> More information: <https://manned.org/showfigfonts>.

- Display available fonts:

`showfigfonts`

- Display available fonts using a specific text:

`showfigfonts {{input_text}}`
