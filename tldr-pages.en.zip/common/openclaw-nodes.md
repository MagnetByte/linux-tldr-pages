# openclaw nodes

> Manage OpenClaw nodes (iOS, Android, macOS devices).
> More information: <https://docs.openclaw.ai/cli/nodes>.

- List all connected and pending nodes:

`openclaw nodes list`

- List pending pairing requests:

`openclaw nodes pending`

- Approve a pending node pairing request:

`openclaw nodes approve {{request_id}}`

- View node status:

`openclaw nodes status`

- Display help:

`openclaw nodes {{[-h|--help]}}`
