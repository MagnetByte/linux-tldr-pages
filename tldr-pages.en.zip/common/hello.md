# hello

> Print "Hello, world!", "hello, world", or a customizable text.
> More information: <https://www.gnu.org/software/hello/manual/hello.html#Invoking-hello>.

- Print "Hello, world!":

`hello`

- Print "hello, world", the traditional type:

`hello {{[-t|--traditional]}}`

- Print a text message:

`hello {{[-g|--greeting]}} "{{greeting_text}}"`
