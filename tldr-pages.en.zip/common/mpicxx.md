# mpicxx

> This command is an alias of `mpic++`.

- View documentation for the original command:

`tldr mpic++`
