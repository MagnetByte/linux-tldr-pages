# rustup check

> Check for updates to Rust toolchains and `rustup`.
> More information: <https://rust-lang.github.io/rustup>.

- Check for all updates:

`rustup check`
