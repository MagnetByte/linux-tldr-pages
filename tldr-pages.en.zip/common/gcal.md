# gcal

> Display calendar.
> More information: <https://www.gnu.org/software/gcal/manual/gcal.html#Invoking-Gcal>.

- Display calendar for the current month:

`gcal`

- Display calendar for the month of February of the year 2010:

`gcal 2 2010`

- Provide calendar sheet with week numbers:

`gcal --with-week-number`

- Change starting day of week to 1st day of the week (Monday):

`gcal --starting-day=1`

- Display the previous, current, and next month surrounding today:

`gcal .`
