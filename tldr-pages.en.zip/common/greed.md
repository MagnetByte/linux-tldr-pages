# greed

> Simple puzzle game.
> Clear as much of the board as you can.
> More information: <https://manned.org/greed>.

- Start the game:

`greed`

- Open help:

`<?>`

- Toggle move [p]reviews:

`<p>`

- Quit:

`<q><y>`

- Print [s]cores:

`greed -s`

- Play with a custom board size and seed:

`greed -w {{width}} -h {{height}} -r {{seed}}`
