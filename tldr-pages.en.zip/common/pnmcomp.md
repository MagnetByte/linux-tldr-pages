# pnmcomp

> This command has been superseded by `pamcomp`.
> More information: <https://netpbm.sourceforge.net/doc/pnmcomp.html>.

- View documentation for the current command:

`tldr pamcomp`
