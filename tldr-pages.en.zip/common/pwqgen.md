# pwqgen

> Generate a random passphrase.
> More information: <https://manned.org/pwqgen>.

- Generate a passphrase:

`pwqgen`

- Generate a passphrase with a specific bit size between 24 and 136:

`pwqgen random={{24..136}}`

- Use a config file to control password generation:

`pwqgen config={{path/to/config_file}}`

- Display help:

`pwqgen {{[-h|--help]}}`

- Display version:

`pwqgen --version`
