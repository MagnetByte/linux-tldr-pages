# mc

> `mc` can refer to multiple commands with the same name.

- View documentation for MinIO client:

`tldr mc.cli`

- View documentation for Midnight Commander:

`tldr mc.fm`
