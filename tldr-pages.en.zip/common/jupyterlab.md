# jupyterlab

> This command is an alias of `jupyter lab`.

- View documentation for the original command:

`tldr jupyter lab`
