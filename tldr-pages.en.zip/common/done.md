# done

> This shell keyword is used with `for`, `while`, `select`, and `until` to mark the end of a loop.

- View documentation for the `for` keyword:

`tldr for`

- View documentation for the `while` keyword:

`tldr while`

- View documentation for the `select` keyword:

`tldr select`

- View documentation for the `until` keyword:

`tldr until`
