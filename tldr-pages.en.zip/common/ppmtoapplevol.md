# ppmtoapplevol

> Convert a PPM image into an Apple volume label image.
> More information: <https://netpbm.sourceforge.net/doc/ppmtoapplevol.html>.

- Convert a PPM image into an Apple volume label image:

`ppmtoapplevol {{path/to/image.ppm}} > {{path/to/output}}`
