# yadm-bootstrap

> Execute Yadm's bootstrap file.
> This file should be created in `$HOME/.config/yadm/bootstrap`.
> More information: <https://yadm.io/docs/bootstrap>.

- Execute bootstrap executable:

`yadm bootstrap`
