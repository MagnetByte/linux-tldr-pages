# pamedge

> Perform edge-detection on a Netpbm image.
> More information: <https://netpbm.sourceforge.net/doc/pamedge.html>.

- Perform edge-detection on a Netpbm image:

`pamedge {{path/to/input.pam}} > {{path/to/output.pam}}`
