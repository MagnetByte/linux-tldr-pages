# impacket-getArch

> This command is an alias of `getArch.py`.

- View documentation for the original command:

`tldr getArch.py`
