# pbmtoicon

> This command has been superseded by `pbmtosunicon`.
> More information: <https://netpbm.sourceforge.net/doc/pbmtoicon.html>.

- View documentation for the current command:

`tldr pbmtosunicon`
