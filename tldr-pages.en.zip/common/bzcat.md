# bzcat

> This command is an alias of `bzip2 --decompress --stdout`.

- View documentation for the original command:

`tldr bzip2`
