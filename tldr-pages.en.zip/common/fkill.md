# fkill

> Fabulously kill processes. Cross-platform.
> More information: <https://manned.org/fkill>.

- Run without arguments to use the interactive interface:

`fkill`

- Kill the process by PID, name, or port:

`fkill {{process_id|process_name|:port}}`
