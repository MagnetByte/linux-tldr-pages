# sfdk build-init

> Initialize build directory.
> More information: <https://github.com/sailfishos/sailfish-qtcreator/blob/master/share/qtcreator/sfdk/modules/20-building-mb2/doc/command.build-init.adoc>.

- Initialize the current directory as the build directory:

`sfdk build-init`

- Initialize the specified directory as the build directory:

`sfdk build-init {{directory}}`
