# cargo uninstall

> Remove a Rust binary installed globally using `cargo install`.
> More information: <https://doc.rust-lang.org/cargo/commands/cargo-uninstall.html>.

- Remove an installed binary:

`cargo uninstall {{package_spec}}`
