# impacket-sniff

> This command is an alias of `sniff.py`.

- View documentation for the original command:

`tldr sniff.py`
