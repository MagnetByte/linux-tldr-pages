# pbmtocmuwm

> Convert a PBM image to a CMU window manager bitmap.
> See also: `cmuwmtopbm`.
> More information: <https://netpbm.sourceforge.net/doc/pbmtocmuwm.html>.

- Convert a PBM image to a CMU window manager bitmap:

`pbmtocmuwm {{path/to/image.pbm}} > {{path/to/output.bmp}}`
