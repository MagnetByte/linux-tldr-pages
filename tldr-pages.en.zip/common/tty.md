# tty

> Returns terminal name.
> More information: <https://www.gnu.org/software/coreutils/manual/html_node/tty-invocation.html>.

- Print the file name of this terminal:

`tty`
