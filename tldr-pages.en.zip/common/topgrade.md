# topgrade

> Update all applications on the system.
> More information: <https://github.com/r-darwish/topgrade>.

- Run updates:

`topgrade`

- Say yes to all updates:

`topgrade {{[-y|--yes]}}`

- Cleanup temporary/old files:

`topgrade {{[-c|--cleanup]}}`

- Disable a certain update operation:

`topgrade --disable {{operation}}`

- Only perform a certain update operation:

`topgrade --only {{operation}}`

- Edit the configuration file with default editor:

`topgrade --edit-config`
