# yadm-decrypt

> Decrypt files that were encrypted by `yadm`.
> When activating this command you will be prompted for a password.
> More information: <https://yadm.io/docs/encryption>.

- Decrypt files:

`yadm decrypt`
