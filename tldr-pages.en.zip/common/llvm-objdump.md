# llvm-objdump

> This command is an alias of `objdump`.

- View documentation for the original command:

`tldr objdump`
