# odpscmd

> Aliyun ODPS (Open Data Processing Service) command-line tool.
> Some subcommands such as `inst` have their own usage documentation.
> More information: <https://www.alibabacloud.com/help/en/maxcompute/user-guide/maxcompute-client>.

- Start the command-line with a custom configuration file:

`odpscmd --config={{odps_config.ini}}`

- [Interactive] Switch current project:

`use {{project_name}};`

- [Interactive] Show tables in the current project:

`show tables;`

- [Interactive] Describe a table:

`desc {{table_name}};`

- [Interactive] Show table partitions:

`show partitions {{table_name}};`

- [Interactive] Describe a partition:

`desc {{table_name}} partition ({{partition_spec}});`
