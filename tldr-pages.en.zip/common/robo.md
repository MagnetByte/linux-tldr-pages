# robo

> PHP task runner.
> More information: <https://robo.li/getting-started.html>.

- List available commands:

`robo list`

- Run a specific command:

`robo {{command}}`

- Simulate running a specific command:

`robo --simulate {{command}}`
