# rustup help

> Display help on `rustup` and its subcommands.
> More information: <https://rust-lang.github.io/rustup/>.

- Display help:

`rustup help`

- Display help for a subcommand:

`rustup help {{subcommand}}`
