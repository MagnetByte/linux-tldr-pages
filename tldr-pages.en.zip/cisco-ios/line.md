# line

> Manage lines.
> Accessed in configuration mode.
> More information: <https://www.cisco.com/c/en/us/td/docs/routers/sdwan/command/iosxe/qualified-cli-command-reference-guide/m-line-commands.pdf?utm_source=chatgpt.com>.

- Configure lines from 0 to 15:

`line vty 0 15`
