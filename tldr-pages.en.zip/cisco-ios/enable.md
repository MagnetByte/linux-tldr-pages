# enable

> Enter privileged execution mode.
> More information: <https://www.cisco.com/c/en/us/td/docs/ios-xml/ios/ios_shl/command/ios-shell-cr-book/ios-shell-cr-a1.html>.

- Enter privileged execution mode:

`enable`
