# gcb

> This command is an alias of `Get-Clipboard`.

- View documentation for the original command:

`tldr get-clipboard`
