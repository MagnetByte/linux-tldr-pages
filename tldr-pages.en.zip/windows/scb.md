# scb

> This command is an alias of `Set-Clipboard`.

- View documentation for the original command:

`tldr Set-Clipboard`
