# scb

> This command is an alias of `Set-Clipboard`.

- View documentation:

`tldr Set-Clipboard`
