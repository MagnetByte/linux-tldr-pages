# ventoy

> This command is an alias of `Ventoy2Disk`.

- View documentation for the original command:

`tldr ventoy2disk`
