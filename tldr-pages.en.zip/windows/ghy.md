# ghy

> This command is an alias of `Get-History`.

- View documentation for the original command:

`tldr Get-History`
