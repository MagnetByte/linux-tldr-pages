# mimikatz service

> Manage Windows services through mimikatz.
> More information: <https://github.com/gentilkiwi/mimikatz>.

- Start a service:

`mimikatz "service::start service_name"`

- Stop a service:

`mimikatz "service::stop service_name"`

- Delete a service:

`mimikatz "service::delete service_name"`
