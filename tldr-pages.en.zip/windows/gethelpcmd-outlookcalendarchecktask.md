# GetHelpCmd OutlookCalendarCheckTask

> Scan for calendar configuration issues in legacy Microsoft Outlook applications.
> Note: This command is deprecated and will not work in the new Outlook application.
> Part of `GetHelpCmd.exe`, formerly `SaRAcmd.exe` (Microsoft Support and Recovery Assistant).
> More information: <https://learn.microsoft.com/troubleshoot/microsoft-365/admin/miscellaneous/get-help-outlook-calendar-scan>.

- Analyze the calendar for the current, active profile, and accept this command's End-User License Agreement (EULA):

`GetHelpCmd.exe -S OutlookCalendarCheckTask -AcceptEula`

- Analyze calendar for a specific Outlook profile:

`GetHelpCmd.exe -S OutlookCalendarCheckTask -AcceptEula -P {{profile}}`

- Analyze the calendar for a specific profile and save the logs to a specific directory:

`GetHelpCmd.exe -S OutlookCalendarCheckTask -AcceptEula -P {{profile}} -LogFolder {{path\to\directory}}`

- Analyze the calendar for a specific profile without showing the progress:

`GetHelpCmd.exe -S OutlookCalendarCheckTask -AcceptEula -P {{profile}} -HideProgress`
