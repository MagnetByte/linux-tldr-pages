# Expand-Archive

> A cmdlet in PowerShell is used to extract files from a compressed archive.
> More information: <https://learn.microsoft.com/powershell/module/microsoft.powershell.archive/expand-archive>.

- Extract a ZIP file to a folder:

`Expand-Archive -Path {{path\to\example.zip}} -DestinationPath {{path\to\extracted_files}}`

- Overwrite existing files:

`Expand-Archive -Path {{path\to\example.zip}} -DestinationPath {{path\to\extracted_files}} -Force`

- Simulate extracting an archive without extracting anything:

`Expand-Archive -Path {{path\to\example.zip}} -DestinationPath {{path\to\extracted_files}} -WhatIf`
