# winword

> Microsoft Office's word processor application.
> More information: <https://support.microsoft.com/office/command-line-switches-for-microsoft-office-products-079164cd-4ef5-4178-b235-441737deb3a6#category=word>.

- Launch the word processor application:

`winword`

- Launch Word with [n]o open documents:

`winword /n`

- [w]rite a new blank document:

`winword /w`

- Create a new document [f]rom (based on) an existing file:

`winword /f {{path\to\file.docx}}`

- Open one or more files for edi[t]ing:

`winword /t {{path\to\file1.docx path\to\file2.docx ...}}`

- Open a file with all AutoExec [m]acros disabled:

`winword /m {{path\to\file.docm}}`

- Open a file with all AutoExec [m]acros disabled, then run a specific macro:

`winword /m{{MacroName}} {{path\to\file.docm}}`

- Start Microsoft Word in Safe Mode:

`winword /safe`
