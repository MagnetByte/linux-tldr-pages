# clhy

> This command is an alias of `Clear-History`.

- View documentation for the original command:

`tldr Clear-History`
