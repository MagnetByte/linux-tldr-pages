# mimikatz token

> List and manipulate security tokens.
> More information: <https://github.com/gentilkiwi/mimikatz>.

- List tokens:

`mimikatz "token::list"`

- Elevate privileges by impersonating a token:

`mimikatz "token::elevate"`

- Revert to original token:

`mimikatz "token::revert"`
