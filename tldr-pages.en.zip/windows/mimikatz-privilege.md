# mimikatz privilege

> Manage privileges for mimikatz operations.
> More information: <https://github.com/gentilkiwi/mimikatz>.

- Enable debug privilege (required for many modules):

`mimikatz "privilege::debug"`

- Check current privilege state:

`mimikatz "privilege::whoami"`
