# gl

> In PowerShell, this command is an alias of `Get-Location`.

- View documentation for the original command:

`tldr get-location`
