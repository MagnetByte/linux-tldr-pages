# sal

> This command is an alias of `Set-Alias`.

- View documentation for the original command:

`tldr set-alias`
