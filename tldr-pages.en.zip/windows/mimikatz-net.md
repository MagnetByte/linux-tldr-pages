# mimikatz net

> Perform network and domain operations.
> More information: <https://github.com/gentilkiwi/mimikatz>.

- List domain users:

`mimikatz "net::users"`

- List domain computers:

`mimikatz "net::computers"`

- Retrieve domain controller information:

`mimikatz "net::domaincontrollers"`
