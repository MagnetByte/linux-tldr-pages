# clear

> In PowerShell, this command is an alias of `Clear-Host`.

- View documentation for the original command:

`tldr clear-host`
