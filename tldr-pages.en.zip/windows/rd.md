# rd

> This command is an alias of `rmdir` on the Command Prompt and `Remove-Item` in PowerShell.

- View documentation for the original Command Prompt command:

`tldr rmdir`

- View documentation for the original PowerShell command:

`tldr remove-item`
