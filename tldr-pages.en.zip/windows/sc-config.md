# sc config

> This command is an alias of `sc.exe config`.

- View documentation for the original command:

`tldr sc`
