# Get-History

> Display PowerShell command history.
> Note: This command can only be used through PowerShell.
> More information: <https://learn.microsoft.com/powershell/module/microsoft.powershell.core/get-history>.

- Display the commands history list with ID:

`Get-History`

- Get PowerShell history item by ID:

`Get-History -Id {{item_id}}`

- Display the last `n` commands:

`Get-History -Count {{n}}`
