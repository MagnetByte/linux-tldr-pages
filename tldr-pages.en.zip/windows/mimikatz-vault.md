# mimikatz vault

> Extract credentials stored in the Windows Credential Vault.
> More information: <https://github.com/gentilkiwi/mimikatz>.

- List vault credentials:

`mimikatz "vault::list"`

- Dump all vault credentials:

`mimikatz "vault::cred"`
