# chrome

> This command is an alias of `chromium`.
> More information: <https://www.google.com/chrome/>.

- View documentation for the original command:

`tldr chromium`
