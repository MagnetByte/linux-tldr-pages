# Clear-Host

> Clears the screen.
> Note: This command can only be used through PowerShell.
> More information: <https://learn.microsoft.com/powershell/module/microsoft.powershell.core/clear-host>.

- Clear the screen:

`cls`
