# ren

> This command is an alias of `Rename-Item`.

- View documentation for original command:

`tldr Rename-Item`
