# sc query

> This command is an alias of `sc.exe query`.

- View documentation for the original command:

`tldr sc`
