# gal

> In PowerShell, this command is an alias of `Get-Alias`.

- View documentation for the original command:

`tldr get-alias`
