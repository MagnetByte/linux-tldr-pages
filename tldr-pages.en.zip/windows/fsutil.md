# fsutil

> Display information about filesystem volumes.
> More information: <https://learn.microsoft.com/windows-server/administration/windows-commands/fsutil>.

- Display a list of volumes:

`fsutil volume list`

- Display information about a volume's filesystem:

`fsutil fsInfo volumeInfo {{drive_letter|path/to/volume}}`

- Display the current state of the filesystem auto-repair for all volumes:

`fsutil repair state`

- Display the dirty bit state of all volumes:

`fsutil dirty query`

- Set the dirty bit state of a volume:

`fsutil dirty set {{drive_letter|path/to/volume}}`
