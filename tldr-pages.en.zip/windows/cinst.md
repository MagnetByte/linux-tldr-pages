# cinst

> This command is an alias of `choco install`.

- View documentation for the original command:

`tldr choco install`
