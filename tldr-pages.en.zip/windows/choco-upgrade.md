# choco upgrade

> Upgrade one or more packages with Chocolatey.
> More information: <https://docs.chocolatey.org/en-us/choco/commands/upgrade/>.

- Upgrade one or more packages:

`choco upgrade {{package1 package2 ...}}`

- Upgrade to a specific version of a package:

`choco upgrade {{package}} --version {{version}}`

- Upgrade all packages:

`choco upgrade all`

- Upgrade all except specified comma-separated packages:

`choco upgrade all --except "{{package1,package2,...}}"`

- Confirm all prompts automatically:

`choco upgrade {{package}} {{[-y|--yes]}}`

- Specify a custom source to receive packages from:

`choco upgrade {{package}} {{[-s|--source]}} {{source_url|alias}}`

- Provide a username and password for authentication:

`choco upgrade {{package}} {{[-u|--user]}} {{username}} {{[-p|--password]}} {{password}}`
