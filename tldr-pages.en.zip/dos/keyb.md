# KEYB

> Change keyboard layout.
> More information: <https://www.dosbox.com/wiki/KEYB>.

- Set layout:

`KEYB {{us|uk|gr|...}}`
