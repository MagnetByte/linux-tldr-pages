# DEL

> Delete one or more files.
> More information: <https://www.dosbox.com/wiki/Commands#DEL>.

- Delete a file:

`DEL {{path/to/file}}`

- Delete all files matching a pattern:

`DEL {{path/to/*.ext}}`
