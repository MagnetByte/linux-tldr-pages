# IMGMOUNT

> Mount disk or CD-ROM images.
> More information: <https://www.dosbox.com/wiki/IMGMOUNT>.

- Mount floppy:

`IMGMOUNT a {{floppy.img}}`

- Mount CD-ROM:

`IMGMOUNT d {{cd.iso}}`
