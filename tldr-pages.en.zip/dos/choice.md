# CHOICE

> Wait for keypress and set `ERRORLEVEL` in batch scripts.
> More information: <https://www.dosbox.com/wiki/Commands#CHOICE>.

- Prompt for yes/no:

`CHOICE "{{prompt}}"`
