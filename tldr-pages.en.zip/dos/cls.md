# CLS

> Clear the screen and reset colors.
> More information: <https://help.fdos.org/en/hhstndrd/batch/cls.htm>.

- Clear the screen resetting colors to white on black:

`CLS`
