# LOADHIGH

> Load program into upper memory (requires `xms=true`, `umb=true`).
> More information: <https://www.dosbox.com/wiki/Commands#LOADHIGH>.

- Load program into upper memory:

`LOADHIGH {{program}}`
