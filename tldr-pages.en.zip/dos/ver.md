# VER

> View/set reported DOS version.
> More information: <https://www.dosbox.com/wiki/Commands#VER>.

- Set version:

`VER set {{major_version}} {{minor_version}}`
