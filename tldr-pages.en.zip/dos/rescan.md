# RESCAN

> Refresh mounted drives (like CTRL-F4).
> More information: <https://www.dosbox.com/wiki/RESCAN>.

- Refresh mounted drives:

`RESCAN`
