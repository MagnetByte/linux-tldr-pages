# RD

> Remove a directory.
> More information: <https://www.dosbox.com/wiki/Commands#RD>.

- Remove directory:

`RD {{path\to\directory}}`
