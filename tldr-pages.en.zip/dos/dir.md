# DIR

> List files and directories.
> More information: <https://www.dosbox.com/wiki/Commands#DIR>.

- List current directory:

`DIR`

- Pause per page:

`DIR /p`

- Wide view:

`DIR /w`
