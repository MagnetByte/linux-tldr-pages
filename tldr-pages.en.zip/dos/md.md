# MD

> Make a directory.
> More information: <https://www.dosbox.com/wiki/Commands#MD>.

- Create directory:

`MD {{path/to/directory}}`
