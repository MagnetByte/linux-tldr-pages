# REN

> Rename files (use for moving too).
> More information: <https://www.dosbox.com/wiki/Commands#REN>.

- Rename file:

`REN {{path/to/file}} {{new_name}}`
