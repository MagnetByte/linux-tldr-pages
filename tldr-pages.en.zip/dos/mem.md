# MEM

> Display free memory info.
> More information: <https://www.dosbox.com/wiki/Commands#MEM>.

- Display free memory:

`MEM`
