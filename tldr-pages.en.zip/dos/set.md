# SET

> Set/display environment variables.
> More information: <https://www.dosbox.com/wiki/Commands#SET>.

- Set variable:

`SET {{VAR}}={{value}}`
