# TYPE

> Display the contents of a text file.
> More information: <https://www.dosbox.com/wiki/Commands#TYPE>.

- Show file:

`TYPE {{path/to/file.txt}}`
