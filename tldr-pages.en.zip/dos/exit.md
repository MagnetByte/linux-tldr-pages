# EXIT

> Exit DOSBox.
> More information: <https://www.dosbox.com/wiki/Commands#EXIT>.

- Exit DOSBox:

`EXIT`
