# COPY

> Copy files.
> More information: <https://www.dosbox.com/wiki/Commands#COPY>.

- Copy a file:

`COPY {{path/to/source_file}} {{path/to/destination_file}}`
