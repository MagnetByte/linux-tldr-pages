# sw_vers

> Print macOS operating system version information.
> More information: <https://keith.github.io/xcode-man-pages/sw_vers.1.html>.

- Print all available information (OS name, version number, and build):

`sw_vers`

- Print only the version number of the operating system:

`sw_vers -productVersion`

- Print only the build identifier:

`sw_vers -buildVersion`
