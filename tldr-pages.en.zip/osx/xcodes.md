# xcodes

> Download, install, and manage multiple Xcode versions.
> Some subcommands such as `runtimes` have their own usage documentation.
> More information: <https://github.com/xcodesorg/xcodes#commands>.

- List all installed Xcode versions:

`xcodes installed`

- List all available Xcode versions:

`xcodes list`

- Select an Xcode version by specifying a version number or a path:

`xcodes select {{xcode_version|path/to/Xcode.app}}`

- Download and install a specific Xcode version:

`xcodes install {{xcode_version}}`

- Install the latest Xcode release and select it:

`xcodes install --latest --select`

- Download a specific Xcode version archive to a given directory without installing it:

`xcodes download {{xcode_version}} --directory {{path/to/directory}}`
