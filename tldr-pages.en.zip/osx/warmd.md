# warmd

> Control caches used during startup and login.
> Note: It should not be invoked manually.
> More information: <https://keith.github.io/xcode-man-pages/warmd.8.html>.

- Start the daemon:

`warmd`
