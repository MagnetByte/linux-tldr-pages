# bugreport

> Show an Android bug report.
> This command can only be used through `adb shell`.
> More information: <https://cs.android.com/android/platform/superproject/+/main:frameworks/native/cmds/bugreport>.

- Display a complete bug report of an Android device:

`bugreport`
