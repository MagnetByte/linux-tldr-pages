# dalvikvm

> Android Java virtual machine.
> More information: <https://source.android.com/docs/core/runtime>.

- Start a specific Java program:

`dalvikvm -classpath {{path/to/file.jar}} {{classname}}`
