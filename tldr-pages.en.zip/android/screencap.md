# screencap

> Take a screenshot of a mobile display.
> This command can only be used through `adb shell`.
> More information: <https://developer.android.com/tools/adb#screencap>.

- Take a screenshot:

`screencap {{path/to/file}}`
