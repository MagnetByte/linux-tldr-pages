# acpi_listen

> Listen to ACPI events.
> More information: <https://manned.org/acpi_listen>.

- Listen to any ACPI event while the daemon is running:

`acpi_listen`

- Display help:

`acpi_listen {{[-h|--help]}}`
