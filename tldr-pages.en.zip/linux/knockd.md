# knockd

> Port knocking daemon to listen for port knocking and execute scripts.
> More information: <https://manned.org/knockd>.

- Start knockd system daemon:

`knockd {{[-d|--daemon]}}`

- Use specified configuration file for knockd:

`knockd {{[-c|--config]}} {{path/to/file}}.configuration`
