# lsmod

> Show the status of Linux kernel modules.
> See also: `kmod` for other module management commands.
> More information: <https://manned.org/lsmod>.

- List all currently loaded kernel modules:

`lsmod`
