# lsmod

> Show the status of Linux kernel modules.
> See also: `kmod`.
> More information: <https://manned.org/lsmod>.

- List all currently loaded kernel modules:

`lsmod`
