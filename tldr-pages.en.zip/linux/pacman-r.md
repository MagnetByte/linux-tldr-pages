# pacman -R

> This command is an alias of `pacman --remove`.

- View documentation for the original command:

`tldr pacman remove`
