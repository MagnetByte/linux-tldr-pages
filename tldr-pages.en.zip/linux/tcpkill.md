# tcpkill

> Kill specified in-progress TCP connections.
> More information: <https://manned.org/tcpkill>.

- Kill in-progress connections at a specified interface, host, and port:

`tcpkill -i {{eth1}} host {{192.95.4.27}} and port {{2266}}`
