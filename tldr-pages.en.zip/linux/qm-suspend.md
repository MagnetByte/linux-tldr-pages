# qm suspend

> Suspend a virtual machine (VM) in the Proxmox Virtual Environment (PVE).
> Use `--skiplock` and `--skiplockstorage` flags with caution, as they may lead to data corruption in certain situations.
> More information: <https://pve.proxmox.com/pve-docs/qm.1.html#cli_qm_suspend>.

- Suspend a virtual machine by ID:

`qm {{[su|suspend]}} {{100}} {{integer}}`

- Skip the lock check when suspending the VM:

`qm {{[su|suspend]}} {{100}} {{integer}} --skiplock`

- Skip the lock check for storage when suspending the VM:

`qm {{[su|suspend]}} {{100}} {{integer}} --skiplockstorage`
