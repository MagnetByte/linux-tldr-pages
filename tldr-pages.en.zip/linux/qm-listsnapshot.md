# qm listsnapshot

> List snapshots of virtual machines.
> More information: <https://pve.proxmox.com/pve-docs/qm.1.html>.

- List all snapshots of a specific virtual machine:

`qm {{[lists|listsnapshot]}} {{vm_id}}`
