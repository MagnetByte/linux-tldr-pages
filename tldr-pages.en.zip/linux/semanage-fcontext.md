# semanage fcontext

> Manage persistent SELinux security context rules on files/directories.
> See also: `matchpathcon`, `secon`, `chcon`, `restorecon`.
> More information: <https://manned.org/semanage-fcontext>.

- List all file labeling rules:

`sudo semanage fcontext {{[-l|--list]}}`

- List all user-defined file labeling rules without headings:

`sudo semanage fcontext {{[-lCn|--list --locallist --noheading]}}`

- Add a user-defined rule that labels any path which matches a PCRE `regex`:

`sudo semanage fcontext {{[-a|--add]}} {{[-t|--type]}} {{samba_share_t}} '{{/mnt/share(/.*)?}}'`

- Add a user-defined rule that creates a labeling equivalence between two subpaths:

`sudo semanage fcontext {{[-a|--add]}} {{[-e|--equal]}} /{{path/to/ref}} /{{path/to/target}}`

- Delete a user-defined rule using its PCRE `regex`:

`sudo semanage fcontext {{[-d|--delete]}} '{{/mnt/share(/.*)?}}'`

- Relabel a directory recursively by applying the new rules:

`restorecon -Rv {{path/to/directory}}`
