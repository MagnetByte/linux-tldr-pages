# caffeinate

> Prevent desktop from sleeping.
> More information: <https://manned.org/caffeinate>.

- Prevent desktop from sleeping (use `<Ctrl c>` to exit):

`caffeinate`
