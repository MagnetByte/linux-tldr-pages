# systemctl condreload

> This command is an alias of `systemctl try-reload-or-restart`.

- View documentation for the original command:

`tldr systemctl try-reload-or-restart`
