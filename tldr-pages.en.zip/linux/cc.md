# cc

> This command is an alias of `gcc`.

- View documentation for the original command:

`tldr gcc`
