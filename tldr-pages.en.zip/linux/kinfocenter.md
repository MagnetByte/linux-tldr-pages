# kinfocenter

> KDE information center to show system information.
> More information: <https://manned.org/kinfocenter>.

- Open the GUI:

`kinfocenter`

- List all possible KCM modules for `kinfocenter`:

`kinfocenter --list`

- Display help:

`kinfocenter {{[-h|--help]}}`
