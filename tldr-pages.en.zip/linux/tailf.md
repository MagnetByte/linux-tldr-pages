# tailf

> This command has been superseded by `tail -f`.
> More information: <https://manned.org/tailf>.

- View documentation for the recommended replacement:

`tldr tail`
