# qm resize

> This command is an alias of `qm disk resize`.

- View documentation for the original command:

`tldr qm disk resize`
