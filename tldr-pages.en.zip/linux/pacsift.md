# pacsift

> Query and filter packages.
> More information: <https://github.com/andrewgregory/pacutils/blob/master/doc/pacsift.pod>.

- List all available packages:

`pacsift`

- Filter packages that provide a given package:

`pacsift --satisfies {{package}}`
