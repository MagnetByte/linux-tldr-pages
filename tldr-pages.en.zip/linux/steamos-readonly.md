# steamos-readonly

> Set the readonly status of the filesystem.
> More information: <https://gitlab.com/users/evlaV/projects>.

- Set the filesystem to be mutable:

`sudo steamos-readonly disable`

- Set the filesystem to be read only:

`sudo steamos-readonly enable`
