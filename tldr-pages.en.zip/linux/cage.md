# cage

> Open applications in a kiosk mode.
> See also: `gamescope`.
> More information: <https://github.com/cage-kiosk/cage/blob/master/cage.1.scd>.

- Run an application:

`cage {{application}}`

- Give the application arguments:

`cage -- {{application}} {{arguments}}`

- Hide window [d]ecorations (this can lock you from accessing the terminal):

`cage -d {{application}}`

- Allow [s]witching terminals with `<Ctrl Alt F2>`:

`cage -s {{application}}`

- Run a specific file:

`cage /{{path/to/file}}`

- Display help:

`cage -h`
