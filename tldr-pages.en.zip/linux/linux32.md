# linux32

> This command is an alias of `setarch linux32`.

- View documentation for the original command:

`tldr setarch`
