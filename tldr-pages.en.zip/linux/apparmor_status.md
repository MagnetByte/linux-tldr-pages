# apparmor_status

> This command is an alias of `aa-status`.

- View documentation for the original command:

`tldr aa-status`
