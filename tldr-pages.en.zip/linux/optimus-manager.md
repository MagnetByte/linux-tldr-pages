# optimus-manager

> GPU switching utility for Nvidia Optimus laptops.
> More information: <https://github.com/Askannz/optimus-manager>.

- Switch between different GPU modes:

`optimus-manager --switch {{nvidia|integrated|hybrid}}`

- Clean up:

`optimus-manager --cleanup`
