# trash-empty

> This command has been moved to `trash`.

- View documentation for `trash-empty`:

`tldr trash`
