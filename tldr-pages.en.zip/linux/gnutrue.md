# gnutrue

> This command is an alias of GNU `true`.

- View documentation for the original command:

`tldr true`
