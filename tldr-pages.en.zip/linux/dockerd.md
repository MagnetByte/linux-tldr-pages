# dockerd

> A persistent process to start and manage Docker containers.
> More information: <https://docs.docker.com/reference/cli/dockerd/>.

- Run Docker daemon:

`dockerd`

- Run Docker daemon and configure it to listen to specific sockets (UNIX and TCP):

`dockerd {{[-H|--host]}} unix://{{path/to/tmp.sock}} {{[-H|--host]}} tcp://{{ip_address}}`

- Run with specific daemon PID file:

`dockerd {{[-p|--pidfile]}} {{path/to/pid_file}}`

- Run in debug mode:

`dockerd {{[-D|--debug]}}`

- Run and set a specific log level:

`dockerd {{[-l|--log-level]}} {{debug|info|warn|error|fatal}}`
