# pirut

> Graphical frontend for `yum`.
> See also: `yum`.
> More information: <https://manned.org/pirut>.

- Launch `pirut`:

`pirut`
