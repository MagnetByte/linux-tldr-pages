# cacademo

> Display a random ASCII art animation.
> More information: <https://packages.debian.org/sid/caca-utils>.

- View an animation:

`cacademo`
