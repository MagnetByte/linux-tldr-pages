# wpctl

> Manage WirePlumber, a session and policy manager for PipeWire.
> Note: You can use the special name `@DEFAULT_SINK@` in place of `id` to operate on the default sink.
> See also: `pw-cli`.
> More information: <https://pipewire.pages.freedesktop.org/wireplumber/>.

- List all objects managed by WirePlumber:

`wpctl status`

- Print all properties of an object:

`wpctl inspect {{object_id}}`

- Set an object to be the default in its group:

`wpctl set-default {{object_id}}`

- Get the volume of a sink:

`wpctl get-volume {{sink_id}}`

- Set the volume of a sink to `n` percent or increase or decrease it by `n`:

`wpctl set-volume {{sink_id}} {{n%|n%+|n%-}}`

- Filter objects by type:

`wpctl list {{audio|video}} {{devices|sinks|sources}}`

- Increase the volume of a sink by `n` percent but limit the volume below 100%:

`wpctl set-volume {{[-l|--limit]}} 1 {{sink_id}} {{n}}%-`

- Mute/Unmute the default audio sink or source (1 is mute, 0 is unmute):

`wpctl set-mute @DEFAULT_{{SINK|SOURCE}}@ {{1|0|toggle}}`
