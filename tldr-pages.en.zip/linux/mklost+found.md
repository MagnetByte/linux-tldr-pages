# mklost+found

> Create a lost+found directory.
> More information: <https://linux.die.net/man/8/mklost+found>.

- Create a `lost+found` directory in the current directory:

`mklost+found`
