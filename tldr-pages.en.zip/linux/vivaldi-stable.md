# vivaldi-stable

> This command is an alias of `chromium`.
> More information: <https://vivaldi.com>.

- View documentation for the original command:

`tldr chromium`
