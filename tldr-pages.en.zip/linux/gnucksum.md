# gnucksum

> This command is an alias of GNU `cksum`.

- View documentation for the original command:

`tldr cksum`
