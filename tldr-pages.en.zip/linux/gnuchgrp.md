# gnuchgrp

> This command is an alias of GNU `chgrp`.

- View documentation for the original command:

`tldr chgrp`
