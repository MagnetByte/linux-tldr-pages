# archinstall

> Guided Arch Linux installer with a twist.
> More information: <https://archinstall.archlinux.page/installing/guided.html>.

- Start the interactive installer:

`archinstall`
