# groupdel

> Delete existing user groups from the system.
> See also: `groups`, `groupadd`, `groupmod`.
> More information: <https://manned.org/groupdel>.

- Delete an existing group:

`sudo groupdel {{group_name}}`
