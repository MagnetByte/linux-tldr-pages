# rtmon

> Save network state changes to a file.
> More information: <https://manned.org/rtmon>.

- Save all network state changes to a file:

`sudo rtmon {{[f|file]}} {{path/to/file}}`

- Specify the type of change to log:

`sudo rtmon {{[f|file}} {{link|address|route}}`
