# qm rollback

> Rollback the VM state to a specified snapshot.
> More information: <https://pve.proxmox.com/pve-docs/qm.1.html#cli_qm_rollback>.

- Rollback the state of a specific VM to a specified snapshot:

`qm {{[ro|rollback]}} {{100}} {{snap_name}}`
