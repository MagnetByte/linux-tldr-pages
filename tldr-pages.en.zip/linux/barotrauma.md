# Barotrauma

> Start a headless Barotrauma server.
> Note: The server is configured by editing the `serversettings.xml` file in the game directory.
> More information: <https://barotraumagame.com/wiki/Hosting_a_Dedicated_Server>.

- Start the server:

`{{path/to/DedicatedServer}}`
