# cacafire

> Display an animated ASCII fire.
> More information: <https://packages.debian.org/sid/caca-utils>.

- Display the ASCII fire:

`cacafire`
