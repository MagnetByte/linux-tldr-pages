# steamos-session-select

> Manipulate which session is currently in use.
> Note: This command is deprecated, use `steamosctl` instead.
> More information: <https://gitlab.com/users/evlaV/projects>.

- Change to desktop mode:

`steamos-session-select plasma`

- Change to gamemode (sets the system to boot into gamemode if `-persistent` arguments were selected previously):

`steamos-session-select`

- Change to Wayland desktop mode:

`steamos-session-select plasma-wayland`

- Change to Wayland desktop mode and have the device boot to desktop:

`steamos-session-select plasma-wayland-persistent`

- Change to X11 desktop mode and have the device boot to desktop:

`steamos-session-select plasma-x11-persistent`
