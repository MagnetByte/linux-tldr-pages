# qm config

> Display the virtual machine configuration with pending configuration changes applied.
> More information: <https://pve.proxmox.com/pve-docs/qm.1.html#cli_qm_config>.

- Display the virtual machine configuration:

`qm {{[co|config]}} {{100}}`

- Display the current configuration values instead of pending values for the virtual machine:

`qm {{[co|config]}} --current {{true}} {{100}}`

- Fetch the configuration values from the given snapshot:

`qm {{[co|config]}} --snapshot {{snapshot_name}} {{100}}`
