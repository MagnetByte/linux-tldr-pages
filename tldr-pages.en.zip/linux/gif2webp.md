# gif2webp

> Convert a GIF image to WebP.
> More information: <https://developers.google.com/speed/webp/docs/gif2webp>.

- Convert a GIF image to WebP:

`gif2webp {{path/to/image.gif}} -o {{path/to/image.webp}}`
