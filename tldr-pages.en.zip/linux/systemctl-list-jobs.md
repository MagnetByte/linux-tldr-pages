# systemctl list-jobs

> List of active systemd jobs that are currently queued or running on the system.
> More information: <https://www.freedesktop.org/software/systemd/man/latest/systemctl.html#list-jobs%20PATTERN%E2%80%A6>.

- List all active jobs:

`systemctl list-jobs`

- Filter jobs for a specific unit:

`systemctl list-jobs {{unit}}`
