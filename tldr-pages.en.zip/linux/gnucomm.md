# gnucomm

> This command is an alias of GNU `comm`.

- View documentation for the original command:

`tldr comm`
