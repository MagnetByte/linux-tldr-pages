# trash-list

> The examples for this command have been moved together with `trash`.

- View documentation for `trash-list`:

`tldr trash`
