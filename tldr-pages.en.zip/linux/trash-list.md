# trash-list

> This command has been moved to `trash`.

- View documentation for `trash-list`:

`tldr trash`
