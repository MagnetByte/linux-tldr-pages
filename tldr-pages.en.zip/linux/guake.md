# guake

> A drop-down terminal for GNOME.
> More information: <https://github.com/Guake/guake>.

- Toggle Guake visibility:

`<F12>`

- Toggle fullscreen mode:

`<F11>`

- Open a new tab:

`<Ctrl Shift t>`

- Close the terminal:

`<Super x>`

- Go to the previous tab:

`<Ctrl PageUp>`

- Search the selected text in the browser:

`<Ctrl Shift l>`
