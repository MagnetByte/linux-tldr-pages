# cs2

> This command is an alias of `counter strike 2`.

- View documentation for the original command:

`tldr counter strike 2`
