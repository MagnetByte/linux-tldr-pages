# uname26

> This command is an alias of `setarch uname26`.

- View documentation for the original command:

`tldr setarch`
