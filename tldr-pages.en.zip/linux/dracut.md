# dracut

> Generate initramfs images to boot the Linux kernel.
> Dracut uses options from configuration files in `/etc/dracut.conf`, `/etc/dracut.conf.d/*.conf` and `/usr/lib/dracut/dracut.conf.d/*.conf` by default.
> More information: <https://github.com/dracut-ng/dracut-ng/blob/main/man/dracut.8.adoc>.

- Generate an initramfs image for the current kernel without overriding any options:

`dracut`

- Generate an initramfs image for the current kernel and overwrite the existing one:

`dracut {{[-f|--force]}}`

- Generate an initramfs image for a specific kernel:

`dracut --kver {{kernel_version}}`

- List available modules:

`dracut --list-modules`
