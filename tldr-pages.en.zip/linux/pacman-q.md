# pacman -Q

> This command is an alias of `pacman --query`.

- View documentation for the original command:

`tldr pacman query`
