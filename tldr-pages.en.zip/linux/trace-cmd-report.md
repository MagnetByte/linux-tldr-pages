# trace-cmd report

> Display recorded trace events.
> See also: `trace-cmd list`, `trace-cmd record`.
> More information: <https://manned.org/trace-cmd-report>.

- Display the recorded trace:

`sudo trace-cmd report`

- Display the recorded trace for a specific CPU:

`sudo trace-cmd report --cpu {{cpu_number}}`
