# apt moo

> An `APT` easter egg.
> More information: <https://manned.org/apt.8>.

- Print a cow easter egg:

`apt moo`
